self.assetsManifest = {
  "version": "IffRQs0O",
  "assets": [
    {
      "hash": "sha256-9C0RsFYkQ6HC+0z9tHbfbMioBalkvuwIT5mEbCyqr0A=",
      "url": "404.html"
    },
    {
      "hash": "sha256-YgOdAISHHrlBqNs2f/oMVip7YhDxwPW98j4ZiTMpmlY=",
      "url": "Pages/Home.razor.js"
    },
    {
      "hash": "sha256-YV64sz90lmGutzPxiSSQg5AphxzsbOmm+e1ULfE8IKk=",
      "url": "SnowDayPredictor.styles.css"
    },
    {
      "hash": "sha256-dSFHQdzKED8ZEULRDB63q5CbaoPluNws+1mcSFPU8DU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ty9s8qx59o.wasm"
    },
    {
      "hash": "sha256-27kRe5fIcpy7UrkWBK3TWlnYdtwAWOJnhJPWKkGnpI0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.58wgnqu1mi.wasm"
    },
    {
      "hash": "sha256-UL/jk4xG/wA9hSzR7T/NkySLaymzALn7f192bKq4AUo=",
      "url": "_framework/Microsoft.AspNetCore.Components.s588g9xs8f.wasm"
    },
    {
      "hash": "sha256-EScOvyLYbGHyXzhFvrjRm2JZrZ6rIDhmUXRvPgDTopY=",
      "url": "_framework/Microsoft.Extensions.Configuration.33kpvunugc.wasm"
    },
    {
      "hash": "sha256-if+LK/X2QiubYZTpryZvRrMyTu2U2TFOuAkbwh3zGOA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vydvg25cgq.wasm"
    },
    {
      "hash": "sha256-I9RchUtUIR389BC9FoYb+kicxmt1RhJha7WRlbfEbBQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dsinhvif0g.wasm"
    },
    {
      "hash": "sha256-o3DZ22g4zto3RmLtosapeKSFHJzL3VXoNJfcMmtGWGk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3snpc8ocur.wasm"
    },
    {
      "hash": "sha256-MyITvRMYEJ8I+uSvIHrbVjJC/ucwyE7rF2jPgWEtxog=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.30bi26cdl0.wasm"
    },
    {
      "hash": "sha256-r3ALIvSOk0g4dgtBLA1dskSc4tr0FbV4GBi9KLaLyhQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3z07kbhr47.wasm"
    },
    {
      "hash": "sha256-2o41anbTbxpSDCdgiXgltHqZusjWuT1+M9amuIjDsAM=",
      "url": "_framework/Microsoft.Extensions.Logging.efb40z18hz.wasm"
    },
    {
      "hash": "sha256-ZWvLi4uD1DhpugB3wdKLcFn2yjTRZKmZhg7SRHhNgxE=",
      "url": "_framework/Microsoft.Extensions.Options.hpxn5zhjfy.wasm"
    },
    {
      "hash": "sha256-kHdBFA5OWOMEPY2Az5SW/Fua4Wmqv8F6pKmiIpg6VSE=",
      "url": "_framework/Microsoft.Extensions.Primitives.cpcl4kfg57.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-rRq61G5+VpvRhc2RdIUOJdMTUibtZislv30ocJcRdV0=",
      "url": "_framework/Microsoft.JSInterop.betqyv1awt.wasm"
    },
    {
      "hash": "sha256-BgByrnRe9CJwkwp/BIOibyG5+5ZP/a/WQBzjXhxpIy4=",
      "url": "_framework/SnowDayPredictor.68ewclvsqj.wasm"
    },
    {
      "hash": "sha256-KdNyHv0nKivu9Fe5zLs6hNLhy4tsA9jfCT4NkD/r4mU=",
      "url": "_framework/System.Collections.Concurrent.jxiwdea5ua.wasm"
    },
    {
      "hash": "sha256-cgMZBT1i/bRYFDDMml6KDHkxsTvWgPi2gBFFCHMDWE4=",
      "url": "_framework/System.Collections.Immutable.q6k5qdu67c.wasm"
    },
    {
      "hash": "sha256-73ffCZurqd19ykgf7LjXxzb1TLrx2J+lgKAsoRXiv88=",
      "url": "_framework/System.Collections.r13ikhai2d.wasm"
    },
    {
      "hash": "sha256-j4xVR2d1tpwZrUoag5ugeqAMDDfGXlE9q1rpeRzeLQY=",
      "url": "_framework/System.ComponentModel.zvpmoupymb.wasm"
    },
    {
      "hash": "sha256-V8hSjtNoP2PPodcnQkBCuxxXRbyXgw0feC/3ztdb1Sw=",
      "url": "_framework/System.Console.l5a5lkrjd2.wasm"
    },
    {
      "hash": "sha256-rJVTcydznDq5HMdT7Z67I3xbhQMfUlB/S4Pev2arlb4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ojhazo1uyi.wasm"
    },
    {
      "hash": "sha256-U40nDmWhvki2ysl5ZN4nXTJ/25f2Owz3e9BIBOqLS1Y=",
      "url": "_framework/System.IO.Pipelines.5ujx8ulk75.wasm"
    },
    {
      "hash": "sha256-vUeFjgFuiKur+DS15z8xJg3zuPGeEpr5xlayHb+SrJc=",
      "url": "_framework/System.Linq.b6an1dbigg.wasm"
    },
    {
      "hash": "sha256-8QuQlI+GDyWHcN0FjzMvQGAyvJDUV+uMf2ELfyaLsdI=",
      "url": "_framework/System.Memory.j3p0152ymq.wasm"
    },
    {
      "hash": "sha256-5lhQJk4oa1fl7yXO9Fyhr27dWjxyjJ1bn4LPf4GnL7E=",
      "url": "_framework/System.Net.Http.Json.ejqnth2elm.wasm"
    },
    {
      "hash": "sha256-iQ8P3pkktJLLC759b6UHWAMF/otYPdfZTBXeSMXn3vE=",
      "url": "_framework/System.Net.Http.jtd6d6683c.wasm"
    },
    {
      "hash": "sha256-RrAqmAHohERJK6ltedHgbZj7mMAwwgWxs4hS92FGJDM=",
      "url": "_framework/System.Net.Primitives.aficcbn7zu.wasm"
    },
    {
      "hash": "sha256-YPRCZNpqa0DRpXQDmyzUdDGHNj99lPsBpLGKxdepvIU=",
      "url": "_framework/System.Private.CoreLib.ctwazdrl4p.wasm"
    },
    {
      "hash": "sha256-DPf7PG7tj0tFxPJ8Tj6oM2ulCrpGOLbQTFhV1LIebro=",
      "url": "_framework/System.Private.Uri.ssct5j4qy3.wasm"
    },
    {
      "hash": "sha256-jj+hXeHxXtNJ/yFTBFkWF83+YlrVlIlndehUiym2PoQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.yzg2xf6fe9.wasm"
    },
    {
      "hash": "sha256-i51HzJPPB5zLurA48h/4l7d7LCaYcnhbX/r+B/l1ayI=",
      "url": "_framework/System.Runtime.x52e86gqmi.wasm"
    },
    {
      "hash": "sha256-E04MD5+M8yUnUB3bCz1aqecOvGzLKoWYaMzJ+vxfHro=",
      "url": "_framework/System.Security.Cryptography.js9a235qw5.wasm"
    },
    {
      "hash": "sha256-AA6jOaoPm5oQo0W0l4fYCa12tq3b1ZPDVZBQvrZ9658=",
      "url": "_framework/System.Text.Encodings.Web.oyio8sakfa.wasm"
    },
    {
      "hash": "sha256-FDAhGagXKTK2iNM8gR33qe5fJEtNh9vpzIOb09mfbTg=",
      "url": "_framework/System.Text.Json.kms8p9txt8.wasm"
    },
    {
      "hash": "sha256-hAtXhjXwBU6x/lMdYJr5C43+i8jA2ml8+qm7RkEKCwk=",
      "url": "_framework/System.Text.RegularExpressions.8xdg26zk62.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-rUQGKH9lRnhq6heI25hzWpZwahWloTXyuT4wSeACbSc=",
      "url": "_framework/dotnet.1ra9qnp43r.js"
    },
    {
      "hash": "sha256-zE11fbcG2CeLl1Zi+NJgMOfWpdjuUWNte+icrtAO58I=",
      "url": "_framework/dotnet.native.87vtjjdetb.js"
    },
    {
      "hash": "sha256-cxtEpYwNaw5SZcxjGX5684Bzda4TyKmrK7bSsnG0NtA=",
      "url": "_framework/dotnet.native.befq3iek54.wasm"
    },
    {
      "hash": "sha256-2lZh9yO0fnzm3Xt7yV+Kox3DH3nK7L8hDhm84VT1xco=",
      "url": "_framework/dotnet.runtime.2tx45g8lli.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-CsChHlHUYGbuIEdR+5X9lxWNazWkgwxEsDPWRPQmRpQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-JZLuunI39wpDQMETpr8WCDfCb2kBzQUaR1yWsvg81HE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-luuemY5dekzk41o+OKEQvLgi6CvCPjtAFyx+wJcp5w4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-R8nZ+oYUgrUJSu9xVwgfo6E0eCkcVpWrlcR3nKBvo9M=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-d6C5ttDldoHJ+R3l3+V7wivnAx8+8md7eEtTiJmFgDA=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-EpV+zeDjeLEX6+dqRc9QNKSkweuKSSXdxgBKra/t+2k=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-sfxWebOACxk5bc/nf83KpPVcimL4Tq0QxS190WUdQx8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-Qmgk8eVaYC/UWB4deoXGtIwbZPeyyau3zT6LihZ/OsM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-W+W8y6sb948y3gAK0A1dFS9vb0ycPU5zul2+O1Vml9U=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-bMnRR5/0xKaEt5Yk9lZVblTUz64oi+Qp+ikOmJ3RR48=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-uYadLk5BYltMFT3ahk/cjjoD5z7GeaRuSdGTEO/LmVE=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-TmaSpMZ1ip01Jkp73o/1mrO3INPFKqiS8Z9hftMF12A=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-0pMu7drslWWL5KtVZiXPYvnZ3EkCyO6yndH5c23+EGQ=",
      "url": "version.js"
    }
  ]
};
